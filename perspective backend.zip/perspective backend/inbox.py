from flask import Flask, request, jsonify, render_template, redirect, url_for, request, abort 
from flask_sqlalchemy import SQLAlchemy
import requests
from datetime import datetime, timezone
from flask_socketio import SocketIO, emit
from sqlalchemy.exc import SQLAlchemyError

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///whatsapp.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
socketio = SocketIO(app, cors_allowed_origins="*")


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    phone_number = db.Column(db.String(15), unique=True, nullable=False)
    profile_name = db.Column(db.String(50), nullable=False)
    profile_pic = db.Column(db.String(255))  # Assuming you store a URL or file path here
    last_message_time = db.Column(db.DateTime, nullable=True)


class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    is_sent  = db.Column(db.Boolean, default=True, nullable=False)  # True for sent, False for received



# Initialize the database and create tables
with app.app_context():
    db.create_all()


VERIFY_TOKEN = 'TrialInbox'
WHATSAPP_API_URL = 'https://graph.facebook.com/v18.0/214379408423824/messages'
ACCESS_TOKEN = 'EAAFkxnZBSXb8BOyK3lWNEzd1RxnEe21NvjaZCceFp80whgEz7ULK1kx90pWQMMDUDLwk117nacOvNczAtukiUoalzJeGbKNHQFnnE2CBCK4Cqq7T3zT9rf5ZCxaGcZBSv88Ie7l2I6wgvZCGq0v9du0EAjXlFLwObEJv35SGnarZBmvrbJsM2VZAqr78DewUl9PTfn5RdnMVIqfd2eu'




@app.route('/get-users')
def get_users():
    # Fetch all users and sort them by the last message time in descending order
    users = User.query.order_by(User.last_message_time.desc(), User.id).all()
    user_list = []
    for user in users:
        user_list.append({
            'id': user.id,
            'name': user.profile_name,
            'phone': user.phone_number,
            'lastMessageTime': user.last_message_time.isoformat() if user.last_message_time else None,
            'profilePic': user.profile_pic if user.profile_pic else url_for('static', filename='default_profile_pic.png')
        })
    return jsonify(user_list)


@app.route('/send-message/<int:user_id>', methods=['POST'])
def send_message(user_id):
    try:
        # Fetch the user or return a 404 error if not found
        user = User.query.get_or_404(user_id)
        data = request.get_json()

        # Ensure message text is provided
        message_text = data.get('message')
        if not message_text:
            return jsonify({'success': False, 'error': 'Message content is required'}), 400

        # Handle optional tempId
        temp_id = data.get('tempId')

        # Define headers and payload for the external API request
        headers = {'Authorization': f'Bearer {ACCESS_TOKEN}', 'Content-Type': 'application/json'}
        payload = {
            'messaging_product': 'whatsapp',
            'to': user.phone_number,
            'type': 'text',
            'text': {'body': message_text}
        }

        # Make the external API request
        response = requests.post(WHATSAPP_API_URL, headers=headers, json=payload)
        
        # Handle unsuccessful external request
        if response.status_code != 200:
            return jsonify({'success': False, 'error': response.text}), response.status_code

        # Create the message instance
        new_message = Message(user_id=user.id, content=message_text, is_sent=True)
        db.session.add(new_message)
        user.last_message_time = datetime.utcnow()
        db.session.commit()

        # Emit the socketio events for real-time communication
        socketio.emit('update_contact_list', {
            'id': user.id,
            'name': user.profile_name,
            'phone': user.phone_number,
            'profilePic': user.profile_pic if user.profile_pic else url_for('static', filename='default_profile_pic.png'),
            'lastMessageTime': user.last_message_time.isoformat() if user.last_message_time else None
        })

        socketio.emit('new_message', {
            'user_id': user.id,
            'content': message_text,
            'timestamp': datetime.utcnow().isoformat()  # Or however you format the timestamp
        })


        # Return a successful response
        return jsonify({'success': True, 'tempId': temp_id}), 200

    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': 'Database error'}), 500
    except requests.RequestException as e:
        return jsonify({'success': False, 'error': 'External API error'}), 500
    except Exception as e:
        # Catch any other errors that are not explicitly handled
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/conversation/<int:user_id>')
def conversation(user_id):
    user = User.query.get_or_404(user_id)
    messages = Message.query.filter_by(user_id=user.id).order_by(Message.timestamp.asc()).all()
    return render_template('conversation.html', user=user, messages=messages)


@app.route('/webhook', methods=['GET', 'POST'])
def webhook():
    if request.method == 'GET':
        mode = request.args.get('hub.mode')
        token = request.args.get('hub.verify_token')
        challenge = request.args.get('hub.challenge')
        if mode and token:
            if mode == 'subscribe' and token == VERIFY_TOKEN:
                print('WEBHOOK_VERIFIED')
                return challenge
            else:
                return 'Verification token mismatch', 403
    elif request.method == 'POST':
        incoming_message = request.json
        try:
            sender_id = incoming_message['entry'][0]['changes'][0]['value']['contacts'][0]['wa_id']
            message_text = incoming_message['entry'][0]['changes'][0]['value']['messages'][0]['text']['body']
            contact_info = incoming_message['entry'][0]['changes'][0]['value']['contacts'][0]
            profile_name = contact_info.get('profile', {}).get('name', sender_id)
            user = User.query.filter_by(phone_number=sender_id).first()
            if not user:
                user = User(phone_number=sender_id, profile_name=profile_name)
                db.session.add(user)
                db.session.commit()

            new_message = Message(user_id=user.id, content=message_text, is_sent=False)
            db.session.add(new_message)
            user.last_message_time = datetime.utcnow()
            db.session.commit()

            socketio.emit('new_received_message', {
                'user_id': user.id,
                'content': message_text,
                'timestamp': datetime.utcnow().isoformat()
            })
            print(f"Emitted new_message for user_id {user.id} with content: {message_text}")

            socketio.emit('update_contact_list', {
                'id': user.id,
                'name': user.profile_name,
                'phone': user.phone_number,
                'profilePic': user.profile_pic if user.profile_pic else url_for('static', filename='default_profile_pic.png'),
                'lastMessageTime': user.last_message_time.isoformat() if user.last_message_time else None
            })
            print(f"Emitted update_contact_list for user_id {user.id}")
        except (KeyError, IndexError) as e:
            print(f"Error processing incoming message: {e}")
            return jsonify(success=False, error=str(e)), 500

        return jsonify(success=True), 200
    else:
        return 'Invalid request method', 405


@app.route('/get-messages/<int:user_id>')
def get_messages(user_id):
    messages = Message.query.filter_by(user_id=user_id).all()
    messages_formatted = [
        {
            'content': message.content,
            'is_sent': message.is_sent,
            'timestamp': message.timestamp.isoformat()  # You might want to send this as well
        }
        for message in messages
    ]
    return jsonify(messages_formatted)

@app.route('/')
def index():
    users = User.query.all()
    return render_template('index.html', users=users)



@socketio.on('message')
def handle_message(data):
    # This is where you handle incoming messages and broadcast them to clients.
    # 'data' contains the message information.
    socketio.emit('new_message', data)

@socketio.on('message_from_client')
def handle_message(message):
    # Assuming 'message' is a dictionary with 'user_id' and 'content'
    emit('message_from_server', message, broadcast=True)
# In your Flask app, after setting up SocketIO
@socketio.on('connect')
def test_connect():
    emit('new_received_message', {'user_id': 'test_id', 'content': 'Test message from server'})


socketio = SocketIO(app)

if __name__ == '__main__':
    socketio.run(app, debug=True)
